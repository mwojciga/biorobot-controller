package biorobot.test;

public class Test {
	public static void main(String[] args) {
		int a = 21848;
		int b = 10;
		System.out.println(a/b);
	}
}
