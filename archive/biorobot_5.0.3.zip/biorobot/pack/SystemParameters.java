package biorobot.pack;

public class SystemParameters {
	/* NewRouteGUI.java */
	public static final int GAP = 800; // gap between the holes.
	public static final String IMMERSION = "01100"; // immersion.
	public static final String ZTRANSPORT = "01370"; // transport height, measured from 0,0,0.
	public static final int XYVELOCITY = 6; // X and Y motor velocity.
	public static final int ZVELOCITY = 5; // Z motor velocity.
	public static final int BIGHOLE1XCOORD = 2650;
	public static final int BIGHOLE2XCOORD = 10950;
	public static final int BIGHOLEYCOORD = 2340;
	public static int XPOSOFFIRST = 3990;
	public static int YPOSOFFIRST = 1540;
	/* MainGUI.java */
	public static final String PROPERTYFILE = "./conf/conf.properties";
	public static final String CHANGELOGFILE = "conf/changelog.txt";
	public static final String STEP="00010";
	public static final String STEPMORE="01000";
	/* OperationProcessor.java */
	final static int MULTIPLICATOR = 10; // must be the same as on uC.
	final static int TIMEOUT = 2000;
	final static int DATA_RATE = 9600;
	final static int NEWLINE_ASCII = 10;
	final static int DASH_ASCII = 45;
	final static int SPACE_ASCII = 32;
}
