package biorobot.pack;

import gui.pack.MainGUI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;

public class ActionProcessor {
	MainGUI mainGUIfrm = null;
	private ArrayList<String> list = new ArrayList<String>();

	public ActionProcessor(MainGUI mainGUIfrm){
		this.mainGUIfrm = mainGUIfrm;
	}

	public File loadFile() {
		final JFileChooser fileChooser = new JFileChooser();
		int returnVal = fileChooser.showOpenDialog(mainGUIfrm.mainPane);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			try {
				File choosenFile = fileChooser.getSelectedFile();
				mainGUIfrm.txtarMessages.append("Choosen route file: " + choosenFile.getCanonicalPath() + "\n");
				OperationProcessor.logger.info("Choosen route file: " + choosenFile.getCanonicalPath());
				mainGUIfrm.txtChoosenRoutePath.setText(choosenFile.getPath());
				try {
					BufferedReader reader = new BufferedReader(new FileReader(choosenFile));
					String line = "";
					while ((line = reader.readLine()) != null){
						list.add(line);
					}
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				String actualRouteTmp = "";
				for (int i = 0; i < list.size(); i++) {
					actualRouteTmp = actualRouteTmp + i + ": [" + list.get(i) + "]\n";
				}
				mainGUIfrm.txtpnRouteOverview.setText(actualRouteTmp);
				return choosenFile;
			} catch (IOException e) {
				e.printStackTrace();
				// jakie� logi?
			}
		}
		return null;
	}

	public String takeFileAndWriteToString(File inputFile, String onlyThese){
		String outputString = "";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			String line = "";
			while ((line = reader.readLine()) != null){
				if (!onlyThese.equals(null)) {
					if (line.startsWith(onlyThese)) {
						String lineArr[] = line.split("]");
						outputString += lineArr[1] + "\n";
					}
				} else {
					outputString += line + "\n";
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return outputString;
	}
}
