package biorobot.pack;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gui.pack.MainGUI;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.TooManyListenersException;

import org.apache.log4j.Logger;

import biorobot.threads.ActualCoordinates;
import biorobot.threads.Calibrate;
import biorobot.threads.StartRouteFromFile;

public class OperationProcessor implements SerialPortEventListener {

	/* THREADS */
	Calibrate calibrateThread;
	ActualCoordinates actualCoordinatesThread;
	StartRouteFromFile startRouteFromFileThread;

	/* OTHER */
	MainGUI mainGUI;
	private Enumeration availablePorts = null;
	private HashMap portMap = new HashMap();
	private CommPortIdentifier selectedPortIdentifier = null;
	private SerialPort openedSerialPort = null;
	private boolean connectedToPort = false;
	private InputStream inputStream = null;
	private OutputStream outputStream = null;

	public static Logger logger = Logger.getLogger(OperationProcessor.class);
	private String sendedMessage = "initialMessage";
	
	public boolean calibrateDone = false;

	public int actX;
	public int actY;
	public int actZ;
	public int expectedX;
	public int expectedY;
	public int expectedZ;

	byte[] buffer = new byte[1024];
	int bytes;
	String end = "E";
	StringBuilder curMsg = new StringBuilder();
	public String inputMessage = "";

	public OperationProcessor(MainGUI mainGUI) {
		this.mainGUI = mainGUI;
	}

	public void searchForPorts() {
		mainGUI.availablePorts.removeAllItems();
		availablePorts = CommPortIdentifier.getPortIdentifiers();
		while (availablePorts.hasMoreElements()) {
			CommPortIdentifier currentPort = (CommPortIdentifier) availablePorts.nextElement();
			mainGUI.txtarLogs.append("Found port: " + currentPort.getName() + "\n");
			logger.info("Found port: " + currentPort.getName());
			if (currentPort.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				mainGUI.availablePorts.addItem(currentPort.getName());
				portMap.put(currentPort.getName(), currentPort);
				mainGUI.txtarLogs.append(currentPort.getName() + " is a serial port. Added.\n");
				logger.info(currentPort.getName() + " is a serial port. Added.");
			}

		}
	}

	public void connect() {
		mainGUI.txtarMessages.append("Connecting to " + mainGUI.availablePorts.getSelectedItem() + "...\n");
		mainGUI.txtarLogs.append("Connecting to " + mainGUI.availablePorts.getSelectedItem() + "...\n");
		logger.info("Connecting to " + mainGUI.availablePorts.getSelectedItem());
		String selectedPort = (String) mainGUI.availablePorts.getSelectedItem();
		selectedPortIdentifier = (CommPortIdentifier) portMap.get(selectedPort);
		CommPort commPort = null;
		try {
			commPort = selectedPortIdentifier.open("Biorobot", SystemParameters.TIMEOUT);
			openedSerialPort = (SerialPort) commPort;
			openedSerialPort.setSerialPortParams(SystemParameters.DATA_RATE, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
			connectedToPort = true;
			mainGUI.btnConnect.setEnabled(false);
			mainGUI.btnDisconnect.setEnabled(true);
			mainGUI.lblConnectionStatus.setText("Connected to " + commPort.getName());
			mainGUI.lblConnectionStatus.setForeground(Color.BLUE);
			mainGUI.enableAllButtons();
			mainGUI.txtarMessages.append("Successfully connected to " + commPort.getName() + "\n");
			mainGUI.txtarLogs.append("Successfully connected to " + commPort.getName() + "\n");
			logger.info("Successfully connected to " + commPort.getName());
		} catch (PortInUseException e) {
			mainGUI.txtarMessages.append("Could not connect: port is already in use.\n");
			mainGUI.txtarLogs.append("Could not connect: port is already in use.\n");
			logger.info("Could not connect: port is already in use.");
		} catch (Exception e) {
			mainGUI.txtarMessages.append("Could not connect: unknown error.\n");
			mainGUI.txtarMessages.append("Could not connect: " + e.toString() + "\n");
			logger.info("Could not connect: " + e.toString());
		}
	}

	public boolean initIOStream() {
		mainGUI.txtarLogs.append("Opening IOStream.\n");
		logger.info("Opening IOStream.");
		boolean ioStreamOpened = false;
		try {
			inputStream = openedSerialPort.getInputStream();
			outputStream = openedSerialPort.getOutputStream();
			ioStreamOpened = true;
			mainGUI.txtarLogs.append("IOStream successfully opened.\n");
			logger.info("IOStream successfully opened.");
		} catch (IOException e) {
			mainGUI.txtarMessages.append("Could not open IOStream.\n");
			mainGUI.txtarLogs.append("Could not open IOStream. " + e.toString() + "\n");
			logger.info("Could not open IOStream." + e.toString());
		}
		return ioStreamOpened;
	}

	public void initListener() {
		try {
			mainGUI.txtarLogs.append("Initializing listener.\n");
			logger.info("Initializing listener.");
			openedSerialPort.addEventListener(this);
			openedSerialPort.notifyOnDataAvailable(true);
		} catch (TooManyListenersException e) {
			mainGUI.txtarMessages.append("Could not add event listener.\n");
			mainGUI.txtarLogs.append("Could not add event listener. " + e.toString() + "\n");
			logger.info("Could not add event listener. " + e.toString());
		}
	}

	public void disconnect() {
		if (connectedToPort == true) {
			openedSerialPort.removeEventListener();
			openedSerialPort.close();
			mainGUI.txtarMessages.append("Disconnected from " + openedSerialPort.getName() + "\n");
			mainGUI.txtarLogs.append("Disconnected from " + openedSerialPort.getName() + "\n");
			logger.info("Disconnected from " + openedSerialPort.getName());
			try {
				inputStream.close();
				outputStream.close();
				connectedToPort = false;
				mainGUI.lblConnectionStatus.setText("Disconnected!");
				mainGUI.lblConnectionStatus.setForeground(Color.RED);
				mainGUI.btnConnect.setEnabled(true);
				mainGUI.btnDisconnect.setEnabled(false);
				mainGUI.disableAllButtons();
				mainGUI.txtarLogs.append("IOStream closed.\n");
				logger.info("IOStream closed.");
			} catch (IOException e) {
				mainGUI.txtarMessages.append("Could not close IOStream.\n");
				mainGUI.txtarLogs.append("Could not close IOStream." + e.toString() + "\n");
				logger.info("Could not close IOStream." + e.toString());
			}
		} else {
			mainGUI.txtarMessages.append("You are not connected to any port!\n");
			mainGUI.txtarLogs.append("Tried to disconnect, but no port is opened.\n");
			logger.info("Tried to disconnect, but no port is opened.");
		}
	}

	@Override
	public void serialEvent(SerialPortEvent event) {
		if (event.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
			try {
				inputMessage = "";
				bytes = inputStream.read(buffer);
				curMsg.append(new String(buffer, 0, bytes, Charset.forName("UTF-8")));
				int endIdx = curMsg.indexOf(end);
				if (endIdx != -1) {
					inputMessage = curMsg.substring(0, endIdx + end.length()).trim();
					curMsg.delete(0, endIdx + end.length());
					mainGUI.txtarLogs.append("Received: " + inputMessage + "\n");
					logger.info("Received: " + inputMessage);
					System.out.println("[R]: " + inputMessage);
					setActualCoordinates(inputMessage);
					boolean calibrateMS = false;
					boolean calibrating = false;
					boolean actualMS = false;
					boolean errorMS = false;
					boolean lockMS = false;
					boolean compareMS = false;
					calibrateMS = checkIfCalibrate(inputMessage);
					calibrating = checkIfCalibrating(inputMessage);
					actualMS = checkIfActual(inputMessage);
					errorMS = checkIfError(inputMessage);
					lockMS = checkIfLock(inputMessage);
					compareMS = compareMessages(inputMessage, sendedMessage);
					logger.info("Calibrate: " + calibrateMS + "; Actual: " + actualMS + "; Error: " + errorMS + "; Lock: " + lockMS + "; Comparison: " + compareMS + "; Calibrating: " + calibrating);
					if (calibrateMS) {
						calibrateThread.resume();
					}
					if (actualMS) {
						actualCoordinatesThread.resume();
					}
					if (errorMS) {
						mainGUI.txtarMessages.append("Received a message with an error from " + openedSerialPort.getName() + "\n");
						mainGUI.txtarLogs.append("Received a message with an error from " + openedSerialPort.getName() + "\n");
						logger.info("Received a message with an error from " + openedSerialPort.getName());
					}
					if (lockMS && !calibrating) {
						resetThreads();
						mainGUI.txtarMessages.append("The robot has reached the limit switch!\n");
						mainGUI.txtarLogs.append("The robot has reached the limit switch!\n");
						logger.info("The robot has reached the limit switch!");
					}
					if (compareMS && !errorMS && !actualMS) {
						mainGUI.txtarMessages.append("Reached [" + actX + ", " + actY + ", " + actZ + "].\n");
						mainGUI.txtarLogs.append("Reached [" + actX + ", " + actY + ", " + actZ + "].\n");
						logger.info("Reached [" + actX + ", " + actY + ", " + actZ + "].");
						startRouteFromFileThread.resume();
					}
				}
			} catch (IOException e) {
				mainGUI.txtarMessages.append("Error while receiveing data: " + e.toString() + "\n");
				mainGUI.txtarLogs.append("Error while receiveing data: " + e.toString() + "\n");
				logger.info("Error while receiving data: " + e.toString());
			}
		}

	}

	public void writeData(int velocity, int xdir, int ydir, int zdir, String x, String y, String z, String t, int error, int hierarchy) {
		try {
			// Sv9d000x10000y20000z20000t602e0h0E
			// Count the expected values.
			if (xdir == 1) {
				expectedX = actX + Integer.parseInt(x) * SystemParameters.MULTIPLICATOR;
			}
			if (xdir == 0) {
				expectedX = actX - Integer.parseInt(x) * SystemParameters.MULTIPLICATOR;
			}
			if (ydir == 1) {
				expectedY = actY + Integer.parseInt(y) * SystemParameters.MULTIPLICATOR;
			}
			if (ydir == 0) {
				expectedY = actY - Integer.parseInt(y) * SystemParameters.MULTIPLICATOR;
			}
			if (zdir == 1) {
				expectedZ = actZ + Integer.parseInt(z) * SystemParameters.MULTIPLICATOR;
			}
			if (zdir == 0) {
				expectedZ = actZ - Integer.parseInt(z) * SystemParameters.MULTIPLICATOR;
			}
			// if actualZ is greater then SystemParameters.ZTRANSPORT, then set h to 1, to move Z first (because its submerged).
			// also, if we're submerged and we want to move X or Y, it won't allow us to do so. 
			if (actZ > Integer.parseInt(SystemParameters.ZTRANSPORT) * SystemParameters.MULTIPLICATOR + 10) {
				hierarchy = 1;
				if (Integer.parseInt(z) * SystemParameters.MULTIPLICATOR < actZ - Integer.parseInt(SystemParameters.ZTRANSPORT) * SystemParameters.MULTIPLICATOR + 10 && (!x.equals("00000") || !y.equals("00000"))) {
					int newZ = (actZ - Integer.parseInt(SystemParameters.ZTRANSPORT) * SystemParameters.MULTIPLICATOR + 10) / 10;
					z = String.format("%05d", newZ);
					zdir = 0;
					expectedZ = Integer.parseInt(SystemParameters.ZTRANSPORT);
				}
			}
			// Color the expected hole on the GUI
			higlightExpectedHole(expectedX-10, expectedY-10, Color.YELLOW);
			outputStream.flush();
			String toSend = "S".concat("v" + velocity + "d" + xdir + ydir + zdir + "x" + x + "y" + y + "z" + z + "t" + t + "e" + error + "h" + hierarchy + "E");
			sendedMessage = toSend;
			System.out.println("[S]: " + toSend);
			outputStream.write(toSend.getBytes());
			outputStream.flush();
			if (error == 0) {
				mainGUI.txtarMessages.append("Moving by [" + x + ", " + y + ", " + z + "] than waiting " + t + " seconds.\n");
				mainGUI.txtarLogs.append("Sent: " + toSend + "\n");
				logger.info("Sent: " + toSend);
			} else if (error == 2) {
				// ?
			} else if (error == 3) {
				// ?
			} else {
				mainGUI.txtarMessages.append("Robot stopped by the user!\nThis incident will be reported.\n");
				mainGUI.txtarLogs.append("Robot stopped by the user!\nThis incident will be reported.\n");
				logger.info("Robot stopped by the user!");
			}
		} catch (Exception e) {
			mainGUI.txtarMessages.append("Could not write data: " + e.toString() + "\n");
			logger.info("Could not write data: " + e.toString());
		}
	}

	public synchronized void useLoadedFile(File loadedFile) {
		// calibrate();
		// if (calibrateDone) {
			boolean actCoordinatesDone = getActCoordinates();
			if (actCoordinatesDone) {
				mainGUI.txtarMessages.append("Starting route...\n");
				startRouteFromFileThread = new StartRouteFromFile(mainGUI, this, loadedFile);
			}
		// }
	}

	public void calibrate() {
		calibrateDone = false;
		boolean actCoordinatesDone = getActCoordinates();
		if (actCoordinatesDone) {
			mainGUI.txtarMessages.append("Calibrating...\n");
			logger.info("Starting calibration.");
			calibrateThread = new Calibrate(mainGUI, this);
		}
	}
	
	public void calibrated() {
		try {
			// Wait for the calibrateThread to end
			calibrateThread.calibrateThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (calibrateThread.calibrateThread.getState().equals(Thread.State.TERMINATED)) {
			calibrateDone = true;
		}
	}

	public boolean getActCoordinates() {
		boolean actualCoordinatesDone = false;
		mainGUI.txtarMessages.append("Aquiring actual coordinates...\n");
		actualCoordinatesThread = new ActualCoordinates(mainGUI, this);
		try {
			// Wait for the actualCoordinatesThread to end
			actualCoordinatesThread.actualCoordinatesThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (actualCoordinatesThread.actualCoordinatesThread.getState().equals(Thread.State.TERMINATED)) {
			actualCoordinatesDone = true;
		}
		return actualCoordinatesDone;
	}

	public void stopRobotMovement() {
		/* Send the stop message to uC */
		writeData(0, 0, 0, 0, "00000", "00000", "00000", "000", 1, 0);
	}

	public void resetThreads() {
		/* Suspend all the threads */
		if (!actualCoordinatesThread.actualCoordinatesThread.getState().equals(Thread.State.TERMINATED)) {
			actualCoordinatesThread.suspend();
		}
		if (!calibrateThread.calibrateThread.getState().equals(Thread.State.TERMINATED)) {
			calibrateThread.suspend();
		}
		if (!startRouteFromFileThread.startRouteFromFileThread.getState().equals(Thread.State.TERMINATED)) {
			startRouteFromFileThread.suspend();
			startRouteFromFileThread.reset();
			mainGUI.txtpnRouteOverview.setText("");
		}
		mainGUI.routePanel.setExpectedHole(27);
		mainGUI.routePanel.setActualHole(27);
		mainGUI.routePanel.repaint();
	}

	public boolean checkIfLock(String inputMessage) {
		boolean lockInMessage = false;
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int x1lFM = Integer.parseInt(Character.toString(inputMessage.charAt(2)));
		int x2lFM = Integer.parseInt(Character.toString(inputMessage.charAt(3)));
		int y1lFM = Integer.parseInt(Character.toString(inputMessage.charAt(4)));
		int y2lFM = Integer.parseInt(Character.toString(inputMessage.charAt(5)));
		int z1lFM = Integer.parseInt(Character.toString(inputMessage.charAt(6)));
		int z2lFM = Integer.parseInt(Character.toString(inputMessage.charAt(7)));
		if (x1lFM == 0 || x2lFM == 0 || y1lFM == 0 || y2lFM == 0 || z1lFM == 0 || z2lFM == 0) {
			lockInMessage = true;
		}
		return lockInMessage;
	}

	public boolean checkIfCalibrate(String inputMessage) {
		boolean calibrateInMessage = false;
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int xStartFM = inputMessage.indexOf("x") + 1;
		int xEndFM = inputMessage.indexOf("y");
		int yStartFM = inputMessage.indexOf("y") + 1;
		int yEndFM = inputMessage.indexOf("z");
		int zStartFM = inputMessage.indexOf("z") + 1;
		int zEndFM = inputMessage.indexOf("t");
		int xFM = Integer.parseInt(inputMessage.substring(xStartFM, xEndFM));
		int yFM = Integer.parseInt(inputMessage.substring(yStartFM, yEndFM));
		int zFM = Integer.parseInt(inputMessage.substring(zStartFM, zEndFM));
		int cFM = Integer.parseInt(Character.toString(inputMessage.charAt(inputMessage.indexOf("e") + 1)));
		if (cFM == 3 && xFM == 10 && yFM == 10 && zFM == 10) {
			calibrateInMessage = true;
		}
		return calibrateInMessage;
	}

	public boolean checkIfCalibrating(String inputMessage) {
		boolean calibratingInMessage = false;
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int xStartFM = inputMessage.indexOf("x") + 1;
		int xEndFM = inputMessage.indexOf("y");
		int yStartFM = inputMessage.indexOf("y") + 1;
		int yEndFM = inputMessage.indexOf("z");
		int zStartFM = inputMessage.indexOf("z") + 1;
		int zEndFM = inputMessage.indexOf("t");
		int xFM = Integer.parseInt(inputMessage.substring(xStartFM, xEndFM));
		int yFM = Integer.parseInt(inputMessage.substring(yStartFM, yEndFM));
		int zFM = Integer.parseInt(inputMessage.substring(zStartFM, zEndFM));
		int cFM = Integer.parseInt(Character.toString(inputMessage.charAt(inputMessage.indexOf("e") + 1)));
		if (cFM == 3 && (xFM != 10 || yFM != 10 || zFM != 10)) {
			calibratingInMessage = true;
		}
		return calibratingInMessage;
	}

	public boolean checkIfActual(String inputMessage) {
		boolean actualInMessage = false;
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int aFM = Integer.parseInt(Character.toString(inputMessage.charAt(inputMessage.indexOf("e") + 1)));
		if (aFM == 2) {
			actualInMessage = true;
		}
		return actualInMessage;
	}

	public boolean checkIfError(String inputMessage) {
		boolean errorInMessage = false;
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int eFM = Integer.parseInt(Character.toString(inputMessage.charAt(inputMessage.indexOf("e") + 1)));
		if (eFM == 1) {
			errorInMessage = true;
		}
		return errorInMessage;
	}

	public boolean compareMessages(String inputMessage, String sendedMessage) {
		boolean theSame = false;
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int xStartIM = inputMessage.indexOf("x") + 1;
		int xEndIM = inputMessage.indexOf("y");
		int yStartIM = inputMessage.indexOf("y") + 1;
		int yEndIM = inputMessage.indexOf("z");
		int zStartIM = inputMessage.indexOf("z") + 1;
		int zEndIM = inputMessage.indexOf("t");
		int tStartIM = inputMessage.indexOf("t") + 1;
		int tEndIM = inputMessage.indexOf("e");
		int xIM = Integer.parseInt(inputMessage.substring(xStartIM, xEndIM));
		int yIM = Integer.parseInt(inputMessage.substring(yStartIM, yEndIM));
		int zIM = Integer.parseInt(inputMessage.substring(zStartIM, zEndIM));
		int tIM = Integer.parseInt(inputMessage.substring(tStartIM, tEndIM));
		// Sv9d000x00100y00200z00200t602e0h0E - sendedMessage
		int xStartSM = sendedMessage.indexOf("x") + 1;
		int xEndSM = sendedMessage.indexOf("y");
		int yStartSM = sendedMessage.indexOf("y") + 1;
		int yEndSM = sendedMessage.indexOf("z");
		int zStartSM = sendedMessage.indexOf("z") + 1;
		int zEndSM = sendedMessage.indexOf("t");
		int tStartSM = sendedMessage.indexOf("t") + 1;
		int tEndSM = sendedMessage.indexOf("e");
		int xSM = Integer.parseInt(sendedMessage.substring(xStartSM, xEndSM)) * SystemParameters.MULTIPLICATOR;
		int ySM = Integer.parseInt(sendedMessage.substring(yStartSM, yEndSM)) * SystemParameters.MULTIPLICATOR;
		int zSM = Integer.parseInt(sendedMessage.substring(zStartSM, zEndSM)) * SystemParameters.MULTIPLICATOR;
		int tSM = Integer.parseInt(sendedMessage.substring(tStartSM, tEndSM));
		// check if x,y,z,t are the same
		if ((xIM == expectedX || xSM == 0) && (yIM == expectedY || ySM == 0) && (zIM == expectedZ || zSM == 0) && tIM == tSM) {
			theSame = true;
		}
		logger.info("[X:Y:Z][EX:RE:SE:AC]" + "[" + expectedX + ":" + xIM + ":" + xSM + ":" + actX + "]" + "[" + expectedY + ":" + yIM + ":" + ySM + ":" + actY + "]" + "[" + expectedZ + ":" + zIM + ":" + zSM + ":" + actZ + "]" + "[T:" + tSM + ":" + tIM + "]");
		return theSame;
	}

	public void setActualCoordinates(String inputMessage) {
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int xStartFM = inputMessage.indexOf("x") + 1;
		int xEndFM = inputMessage.indexOf("y");
		int yStartFM = inputMessage.indexOf("y") + 1;
		int yEndFM = inputMessage.indexOf("z");
		int zStartFM = inputMessage.indexOf("z") + 1;
		int zEndFM = inputMessage.indexOf("t");
		int xFM = Integer.parseInt(inputMessage.substring(xStartFM, xEndFM));
		int yFM = Integer.parseInt(inputMessage.substring(yStartFM, yEndFM));
		int zFM = Integer.parseInt(inputMessage.substring(zStartFM, zEndFM));
		actX = xFM;
		actY = yFM;
		actZ = zFM;
		higlightActualHole(actX-10, actY-10, Color.BLUE);
		mainGUI.actualPosition.setText("[" + actX + ", " + actY + ", " + actZ + "]");
	}

	public void higlightActualHole(int x, int y, Color color) {
		int holeNo = 27;
		// Check which hole coresponds to given x and y
		if (x == SystemParameters.BIGHOLE1XCOORD * SystemParameters.MULTIPLICATOR && y == SystemParameters.BIGHOLEYCOORD * SystemParameters.MULTIPLICATOR) {
			holeNo = 0;
		} else if (x == SystemParameters.BIGHOLE2XCOORD * SystemParameters.MULTIPLICATOR && y == SystemParameters.BIGHOLEYCOORD * SystemParameters.MULTIPLICATOR) {
			holeNo = 25;
		} else { 
			// Check if these are a proper hole coordinates
			if ((x - SystemParameters.XPOSOFFIRST * SystemParameters.MULTIPLICATOR) % SystemParameters.GAP * SystemParameters.MULTIPLICATOR == 0 && (y - SystemParameters.YPOSOFFIRST * SystemParameters.MULTIPLICATOR) % SystemParameters.GAP * SystemParameters.MULTIPLICATOR == 0 ) {
				// Create an array of possible holes.
				int k = 1;
				int[][] holes = new int[3][8];
				for (int col = 0; col < 8; col++) {
					for (int row = 0; row < 3; row++) {
						holes[row][col] = k;
						k++;
					}
				}
				// Check which row and col is it.
				int xArray = (x - SystemParameters.XPOSOFFIRST * SystemParameters.MULTIPLICATOR) / (SystemParameters.GAP * SystemParameters.MULTIPLICATOR);
				int yArray = (y - SystemParameters.YPOSOFFIRST * SystemParameters.MULTIPLICATOR) / (SystemParameters.GAP * SystemParameters.MULTIPLICATOR);
				// Take the button number.
				holeNo = holes[yArray][xArray];
			} else {
				// TODO If not, draw a cross at actual position and a line to that cross.
			}
		}
		mainGUI.routePanel.setActualColor(color);
		mainGUI.routePanel.setActualHole(holeNo);
		mainGUI.routePanel.repaint();
	}
	
	public void higlightExpectedHole(int x, int y, Color color) {
		int holeNo = 27;
		// Check which hole coresponds to given x and y
		if (x == SystemParameters.BIGHOLE1XCOORD * SystemParameters.MULTIPLICATOR && y == SystemParameters.BIGHOLEYCOORD * SystemParameters.MULTIPLICATOR) {
			holeNo = 0;
		} else if (x == SystemParameters.BIGHOLE2XCOORD * SystemParameters.MULTIPLICATOR && y == SystemParameters.BIGHOLEYCOORD * SystemParameters.MULTIPLICATOR) {
			holeNo = 25;
		} else { 
			// Check if these are a proper hole coordinates
			if ((x - SystemParameters.XPOSOFFIRST * SystemParameters.MULTIPLICATOR) % SystemParameters.GAP * SystemParameters.MULTIPLICATOR == 0 && (y - SystemParameters.YPOSOFFIRST * SystemParameters.MULTIPLICATOR) % SystemParameters.GAP * SystemParameters.MULTIPLICATOR == 0 && x >= 0 & y >=0) {
				// Create an array of possible holes.
				int k = 1;
				int[][] holes = new int[3][8];
				for (int col = 0; col < 8; col++) {
					for (int row = 0; row < 3; row++) {
						holes[row][col] = k;
						k++;
					}
				}
				// Check which row and col is it.
				int xArray = (x - SystemParameters.XPOSOFFIRST * SystemParameters.MULTIPLICATOR) / (SystemParameters.GAP * SystemParameters.MULTIPLICATOR);
				int yArray = (y - SystemParameters.YPOSOFFIRST * SystemParameters.MULTIPLICATOR) / (SystemParameters.GAP * SystemParameters.MULTIPLICATOR);
				// Take the button number.
				holeNo = holes[yArray][xArray];
			} else {
				holeNo = 27;
			}
		}
		mainGUI.routePanel.setExpectedColor(color);
		mainGUI.routePanel.setExpectedHole(holeNo);
		mainGUI.routePanel.repaint();
	}

	/* GETTERS & SETTERS */

	public boolean isConnectedToPort() {
		return connectedToPort;
	}

	public void setConnectedToPort(boolean connectedToPort) {
		this.connectedToPort = connectedToPort;
	}

	public String getSendedMessage() {
		return sendedMessage;
	}

	public void setSendedMessage(String sendedMessage) {
		this.sendedMessage = sendedMessage;
	}

	public String getInputMessage() {
		return inputMessage;
	}

	public void setInputMessage(String inputMessage) {
		this.inputMessage = inputMessage;
	}

	public int getActX() {
		return actX;
	}

	public void setActX(int actX) {
		this.actX = actX;
	}

	public int getActY() {
		return actY;
	}

	public void setActY(int actY) {
		this.actY = actY;
	}

	public int getActZ() {
		return actZ;
	}

	public void setActZ(int actZ) {
		this.actZ = actZ;
	}

}