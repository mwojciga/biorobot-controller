package biorobot.threads;

import gui.pack.MainGUI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import biorobot.pack.OperationProcessor;

public class StartRouteFromFile implements Runnable {

	MainGUI mainGUI;
	OperationProcessor operationProcessor;
	public Thread startRouteFromFileThread;
	
	File loadedFile;
	String task;
	public String message;
	public String fullMessage;
	private ArrayList<String> list = new ArrayList<String>();

	private boolean suspendFlag = true;

	public StartRouteFromFile(MainGUI mainGUI, OperationProcessor operationProcessor, File loadedFile) {
		this.mainGUI = mainGUI;
		this.operationProcessor = operationProcessor;
		startRouteFromFileThread = new Thread(this, "StartRouteFromFileThread");
		startRouteFromFileThread.start();
		this.loadedFile = loadedFile;
	}

	@Override
	public void run() {
		try {
			/* TODO
			 * Policz przy starcie trasy jakie powinny byc ko�cowe koordynaty.
			 * Je�li si� pojawi� i lista si� zako�czy to wy�wietl komunikat.
			 */
			mainGUI.progressBar.setValue(0);
			BufferedReader reader = new BufferedReader(new FileReader(loadedFile));
			String line = "";
			while ((line = reader.readLine()) != null){
				list.add(line);
			}
			reader.close();
			for (int i = 0; i < list.size(); i++) {
				//write
				message = list.get(i);
				// Sv9d000x100y200z200t602e0E
				// Sv9d000x10000y20000z20000t602e0h0E
				int vFile = Integer.parseInt(Character.toString(message.charAt(2)));
				int xDirFile = Integer.parseInt(Character.toString(message.charAt(4)));
				int yDirFile = Integer.parseInt(Character.toString(message.charAt(5)));
				int zDirFile = Integer.parseInt(Character.toString(message.charAt(6)));
				String xFile = message.substring(8, 13);
				String yFile = message.substring(14, 19);
				String zFile = message.substring(20, 25);
				String tFile = message.substring(26, 29);
				int eFile = Integer.parseInt(Character.toString(message.charAt(30)));
				int hFile = Integer.parseInt(Character.toString(message.charAt(32)));
				String toSend = "S".concat("v" + vFile + "d" + xDirFile + yDirFile + zDirFile + "x" + xFile + "y" + yFile + "z" + zFile + "t" + tFile + "e" + eFile + "h" + hFile + "E");
				operationProcessor.writeData(vFile, xDirFile, yDirFile, zDirFile, xFile, yFile, zFile, tFile, eFile, hFile);
				operationProcessor.setSendedMessage(toSend);
				//wait
				if (i != list.size()-1) {
					suspendFlag = true;
					mainGUI.txtarMessages.append("Waiting for response...\n");
					synchronized(this){
						while (suspendFlag) {
							// Wait for OP to read a proper message
							wait();
						}
					}
				}
				int percentageDone = Math.round((i*100.0f)/list.size());
				System.out.println("%: " + percentageDone);
				mainGUI.progressBar.setValue(percentageDone);
				if (i == list.size()-1) {
					mainGUI.progressBar.setValue(0);
					JOptionPane.showMessageDialog(mainGUI, "Trasa zosta�a zako�czona!", "Info", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void suspend() {
		suspendFlag = true;
	}

	public synchronized void resume() {
		suspendFlag = false;
		notify();
	}
	
	public void reset() {
		list.clear();
		mainGUI.progressBar.setValue(0);
	}
}
