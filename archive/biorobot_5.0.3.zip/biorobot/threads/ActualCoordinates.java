package biorobot.threads;

import gui.pack.MainGUI;
import biorobot.pack.OperationProcessor;

public class ActualCoordinates implements Runnable {

	MainGUI mainGUI;
	OperationProcessor operationProcessor;
	public Thread actualCoordinatesThread;

	private boolean suspendFlag = true;

	public ActualCoordinates(MainGUI mainGUI, OperationProcessor operationProcessor) {
		this.mainGUI = mainGUI;
		this.operationProcessor = operationProcessor;
		actualCoordinatesThread = new Thread(this, "ActualCoordinatesThread");
		actualCoordinatesThread.start();
	}

	@Override
	public void run() {
		try {
			/* The uC will read the actual coordinates */
			int vFile = 0;
			int xDirFile = 0;
			int yDirFile = 0;
			int zDirFile = 0;
			String xFile = "00000";
			String yFile = "00000";
			String zFile = "00000";
			String tFile = "000";
			int hFile = 0;
			int eFile = 2;
			operationProcessor.writeData(vFile, xDirFile, yDirFile, zDirFile, xFile, yFile, zFile, tFile, eFile, hFile);
			synchronized (this) {
				while (suspendFlag) {
					// Wait for OP to read a proper message
					wait();
				}
			}
			/* If OP read a message that the robot has actualCoordinated, than... */
			String actFullMessage = operationProcessor.getInputMessage();
			int xStartFM = actFullMessage.indexOf("x") + 1;
			int xEndFM = actFullMessage.indexOf("y");
			int yStartFM = actFullMessage.indexOf("y") + 1;
			int yEndFM = actFullMessage.indexOf("z");
			int zStartFM = actFullMessage.indexOf("z") + 1;
			int zEndFM = actFullMessage.indexOf("t");
			int x = Integer.parseInt(actFullMessage.substring(xStartFM, xEndFM));
			int y = Integer.parseInt(actFullMessage.substring(yStartFM, yEndFM));
			int z = Integer.parseInt(actFullMessage.substring(zStartFM, zEndFM));
			operationProcessor.setActX(x);
			operationProcessor.setActY(y);
			operationProcessor.setActZ(z);
			mainGUI.txtarLogs.append("Actual coordinates message: " + actFullMessage + "\n");
			OperationProcessor.logger.info("Actual coordinates message: " + actFullMessage);
			mainGUI.actualPosition.setText("[" + x + ", " + y + ", " + z + "]");
			mainGUI.txtarMessages.append("Actual coordinates: [" + x + ", " + y + ", " + z + "]\n");
			mainGUI.txtarLogs.append("Actual coordinates: [" + x + ", " + y + ", " + z + "]\n");
			OperationProcessor.logger.info("Actual coordinates: [" + x + ", " + y + ", " + z + "]");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public synchronized void suspend() {
		suspendFlag = true;
	}

	public synchronized void resume() {
		suspendFlag = false;
		notify();
	}

}
