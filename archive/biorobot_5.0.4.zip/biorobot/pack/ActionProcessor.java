package biorobot.pack;

import gui.pack.MainGUI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;

import org.apache.log4j.Logger;

public class ActionProcessor {
	MainGUI mainGUIfrm = null;
	private ArrayList<String> list = new ArrayList<String>();

	/* LOG */
	Logger logger = Logger.getLogger(ActionProcessor.class);
	Log log = new Log();
	
	public ActionProcessor(MainGUI mainGUIfrm){
		this.mainGUIfrm = mainGUIfrm;
	}

	public File loadFile() {
		final JFileChooser fileChooser = new JFileChooser();
		int returnVal = fileChooser.showOpenDialog(mainGUIfrm.mainPane);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			try {
				File choosenFile = fileChooser.getSelectedFile();
				log.log("Choosen route file: " + choosenFile.getCanonicalPath(), null);
				logger.info("Choosen route file: " + choosenFile.getCanonicalPath());
				mainGUIfrm.txtChoosenRoutePath.setText(choosenFile.getPath());
				try {
					BufferedReader reader = new BufferedReader(new FileReader(choosenFile));
					String line = "";
					while ((line = reader.readLine()) != null){
						list.add(line);
					}
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				String actualRouteTmp = "";
				for (int i = 0; i < list.size(); i++) {
					actualRouteTmp = actualRouteTmp + i + ": [" + list.get(i) + "]\n";
				}
				mainGUIfrm.txtpnRouteOverview.setText(actualRouteTmp);
				actualRouteTmp = "";
				return choosenFile;
			} catch (IOException e) {
				log.log("An exception occured. See more in log file.", "An exception occured. See more in log file.");
				logger.error(e.toString());
			}
		}
		return null;
	}

	public String takeFileAndWriteToString(File inputFile, String onlyThese){
		String outputString = "";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			String line = "";
			while ((line = reader.readLine()) != null){
				if (!onlyThese.equals(null)) {
					if (line.startsWith(onlyThese)) {
						String lineArr[] = line.split("]");
						outputString += lineArr[1] + "\n";
					}
				} else {
					outputString += line + "\n";
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return outputString;
	}
}
