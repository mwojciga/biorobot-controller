package biorobot.pack;

import biorobot.data.ExpectedCoordinatesData;
import biorobot.data.InputMessageData;
import biorobot.data.OutputMessageData;

/**
 * Calculates things.
 * @author maciej.wojciga
 */

public class Calculations {
	
	/**
	 * Maps coordinates to hole number.
	 * @param x
	 * @param y
	 * @return
	 */
	public int mapCoordinatesToButtonNo(int x, int y) {
		int holeNo = 27;
		// Check which hole corresponds to given x and y
		if (x == SystemParameters.BIGHOLE1XCOORD * SystemParameters.MULTIPLICATOR && y == SystemParameters.BIGHOLEYCOORD * SystemParameters.MULTIPLICATOR) {
			holeNo = 0;
		} else if (x == SystemParameters.BIGHOLE2XCOORD * SystemParameters.MULTIPLICATOR && y == SystemParameters.BIGHOLEYCOORD * SystemParameters.MULTIPLICATOR) {
			holeNo = 25;
		} else { 
			// Check if these are a proper hole coordinates
			if ((x - SystemParameters.XPOSOFFIRST * SystemParameters.MULTIPLICATOR) % SystemParameters.GAP * SystemParameters.MULTIPLICATOR == 0 && (y - SystemParameters.YPOSOFFIRST * SystemParameters.MULTIPLICATOR) % SystemParameters.GAP * SystemParameters.MULTIPLICATOR == 0 ) {
				// Create an array of possible holes.
				int k = 1;
				int[][] holes = new int[3][8];
				for (int col = 0; col < 8; col++) {
					for (int row = 0; row < 3; row++) {
						holes[row][col] = k;
						k++;
					}
				}
				// Check which row and column is it.
				int xArray = (x - SystemParameters.XPOSOFFIRST * SystemParameters.MULTIPLICATOR) / (SystemParameters.GAP * SystemParameters.MULTIPLICATOR);
				int yArray = (y - SystemParameters.YPOSOFFIRST * SystemParameters.MULTIPLICATOR) / (SystemParameters.GAP * SystemParameters.MULTIPLICATOR);
				// Take the button number.
				holeNo = holes[yArray][xArray];
			} else {
				// TODO If not, draw a cross at actual position and a line to that cross.
			}
		}
		return holeNo;
	}
	
	/**
	 * Maps hole number to coordinates.
	 * Note that you must add after-calibration coordinates to returned values.
	 * @param holeNo
	 * @return
	 */
	public static int[] mapHoleNoToCoordinates(int holeNo) {
		int coordinates[] = new int[2];
		// Check if this is the first or last hole.
		if (holeNo == 0) {
			coordinates[0] = SystemParameters.BIGHOLE1XCOORD;
			coordinates[1] = SystemParameters.BIGHOLEYCOORD;
		}
		if (holeNo == 25) {
			coordinates[0] = SystemParameters.BIGHOLE2XCOORD;
			coordinates[1] = SystemParameters.BIGHOLEYCOORD;
		}
		// Make a map of holes.
		int k = 1;
		int[][] holes = new int[3][8];
		for (int col = 0; col < 8; col++) {
			for (int row = 0; row < 3; row++) {
				holes[row][col] = k;
				k++;
			}
		}
		// Calculate in which row and column is our hole placed.
		int row;
		int column;
		row = (holeNo % SystemParameters.YHOLESNO);
		if (row == 0) {
			row += 3;
			column = (holeNo / SystemParameters.YHOLESNO);
		} else {
			column = (holeNo / SystemParameters.YHOLESNO) + 1;
		}
		// Calculate coordinates.
		int xCoordinate = SystemParameters.XPOSOFFIRST + (SystemParameters.GAP * (column - 1)) * SystemParameters.MULTIPLICATOR;
		int yCoordinate = SystemParameters.YPOSOFFIRST + (SystemParameters.GAP * (row - 1)) * SystemParameters.MULTIPLICATOR;
		coordinates[0] = xCoordinate;
		coordinates[1] = yCoordinate;
		return coordinates;
	}

	/**
	 * Takes input message and outputs useful data.
	 * @param inputMessage
	 * @return
	 */
	public InputMessageData processInputMessage(String inputMessage, InputMessageData inputMessageData) {
		// Sl000000x00000y00000z00000t000e0E - inputMessage
		int lStartIM = inputMessage.indexOf("l") + 1;
		int lEndIM = inputMessage.indexOf("x");
		int xStartIM = inputMessage.indexOf("x") + 1;
		int xEndIM = inputMessage.indexOf("y");
		int yStartIM = inputMessage.indexOf("y") + 1;
		int yEndIM = inputMessage.indexOf("z");
		int zStartIM = inputMessage.indexOf("z") + 1;
		int zEndIM = inputMessage.indexOf("t");
		int tStartIM = inputMessage.indexOf("t") + 1;
		int tEndIM = inputMessage.indexOf("e");
		int eStartIM = inputMessage.indexOf("e") + 1;
		int eEndIM = inputMessage.indexOf("E");
		// Fill DTO with new values.
		String lIM = inputMessage.substring(lStartIM, lEndIM);
		int lockTable[] = new int[6];
		for (int i = 0; i < lIM.length(); i++) {
			lockTable[i] = lIM.charAt(i);
		}
		inputMessageData.setlIM(lockTable);
		inputMessageData.setxIM(Integer.parseInt(inputMessage.substring(xStartIM, xEndIM)));
		inputMessageData.setyIM(Integer.parseInt(inputMessage.substring(yStartIM, yEndIM)));
		inputMessageData.setzIM(Integer.parseInt(inputMessage.substring(zStartIM, zEndIM)));
		inputMessageData.settIM(Integer.parseInt(inputMessage.substring(tStartIM, tEndIM)));
		inputMessageData.seteIM(Integer.parseInt(inputMessage.substring(eStartIM, eEndIM)));
		return inputMessageData;
	}

	/**
	 * Takes output message and outputs useful data.
	 * @param outputMessage
	 * @param outputMessageData
	 * @return
	 */
	public OutputMessageData processOutputMessage(String outputMessage, OutputMessageData outputMessageData) {
		// Sv9d000x00100y00200z00200t602e0h0E - outputMessage
		int vStartOM = outputMessage.indexOf("v") + 1;
		int vEndOM = outputMessage.indexOf("d");
		int dStartOM = outputMessage.indexOf("d") + 1;
		int dEndOM = outputMessage.indexOf("x");
		int xStartOM = outputMessage.indexOf("x") + 1;
		int xEndOM = outputMessage.indexOf("y");
		int yStartOM = outputMessage.indexOf("y") + 1;
		int yEndOM = outputMessage.indexOf("z");
		int zStartOM = outputMessage.indexOf("z") + 1;
		int zEndOM = outputMessage.indexOf("t");
		int tStartOM = outputMessage.indexOf("t") + 1;
		int tEndOM = outputMessage.indexOf("e");
		int eStartOM = outputMessage.indexOf("e") + 1;
		int eEndOM = outputMessage.indexOf("h");
		int hStartOM = outputMessage.indexOf("h") + 1;
		int hEndOM = outputMessage.indexOf("E");
		// Fill DTO with new values.
		outputMessageData.setvOM(Integer.parseInt(outputMessage.substring(vStartOM, vEndOM)));
		String dOM = outputMessage.substring(dStartOM, dEndOM);
		int dirTable[] = new int[3];
		for (int i = 0; i < dOM.length(); i++) {
			dirTable[i] = Character.getNumericValue(dOM.charAt(i));
		}
		outputMessageData.setdOM(dirTable);
		outputMessageData.setxOM(Integer.parseInt(outputMessage.substring(xStartOM, xEndOM)) * SystemParameters.MULTIPLICATOR);
		outputMessageData.setyOM(Integer.parseInt(outputMessage.substring(yStartOM, yEndOM)) * SystemParameters.MULTIPLICATOR);
		outputMessageData.setzOM(Integer.parseInt(outputMessage.substring(zStartOM, zEndOM)) * SystemParameters.MULTIPLICATOR);
		outputMessageData.settOM(Integer.parseInt(outputMessage.substring(tStartOM, tEndOM)));
		outputMessageData.seteOM(Integer.parseInt(outputMessage.substring(eStartOM, eEndOM)));
		outputMessageData.sethOM(Integer.parseInt(outputMessage.substring(hStartOM, hEndOM)));
		return outputMessageData;
	}

	/**
	 * Counts the expected coordinates values.
	 * @param coordinates
	 * @param directories
	 * @param actualCoordinates
	 * @param expectedCoordinatesData
	 * @return
	 */
	public ExpectedCoordinatesData countExpectedCoordinates(int[] coordinates, int[] directories, int[] actualCoordinates, ExpectedCoordinatesData expectedCoordinatesData) {
		if (directories[0] == 1) {
			expectedCoordinatesData.setExpectedX(actualCoordinates[0] + coordinates[0] * SystemParameters.MULTIPLICATOR);
		}
		if (directories[0] == 0) {
			expectedCoordinatesData.setExpectedX(actualCoordinates[0] - coordinates[0] * SystemParameters.MULTIPLICATOR);
		}
		if (directories[1] == 1) {
			expectedCoordinatesData.setExpectedY(actualCoordinates[1] + coordinates[1] * SystemParameters.MULTIPLICATOR);
		}
		if (directories[1] == 0) {
			expectedCoordinatesData.setExpectedY(actualCoordinates[1] - coordinates[1] * SystemParameters.MULTIPLICATOR);
		}
		if (directories[2] == 1) {
			expectedCoordinatesData.setExpectedZ(actualCoordinates[2] + coordinates[2] * SystemParameters.MULTIPLICATOR);
		}
		if (directories[2] == 0) {
			expectedCoordinatesData.setExpectedZ(actualCoordinates[2] - coordinates[2] * SystemParameters.MULTIPLICATOR);
		}
		return expectedCoordinatesData;
	}
}
