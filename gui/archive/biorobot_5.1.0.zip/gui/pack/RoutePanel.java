package gui.pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class RoutePanel extends JPanel {
	private static final long serialVersionUID = 1L;
	final static BasicStroke stroke = new BasicStroke(2.0f);
	public List<Ellipse2D> topPallette;
	public List<Ellipse2D> bottomPallette;

	// At start initialize it with a dumb variable.
	private int actualHole = 27;
	private Color actualColor;
	private int expectedHole = 27;
	private Color expectedColor;

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		// draw smooth circles.
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		// Top palette.
		topPallette = new ArrayList<Ellipse2D>();
		topPallette.add(new Ellipse2D.Double(25, 47.5, 55, 55));
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 3; j++) {
				topPallette.add(new Ellipse2D.Double(86.25+i*25, 41.25+j*25, 17.5, 17.5));
			}
		}
		topPallette.add(new Ellipse2D.Double(285, 47.5, 55, 55));
		// Bottom palette.
		List<Ellipse2D> bottomPallette = new ArrayList<Ellipse2D>();
		bottomPallette.add(new Ellipse2D.Double(25, 147.5, 55, 55));
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 3; j++) {
				bottomPallette.add(new Ellipse2D.Double(86.25+i*25, 141.25+j*25, 17.5, 17.5));
			}
		}
		bottomPallette.add(new Ellipse2D.Double(285, 147.5, 55, 55));

		// Draw palettes.
		g2.setStroke(stroke);
		for (int i = 0; i < topPallette.size(); i++) {
			g2.draw(topPallette.get(i));
		}
		for (int i = 0; i < bottomPallette.size(); i++) {
			g2.draw(bottomPallette.get(i));
		}
		// Fill palettes.
		g2.setPaint(Color.LIGHT_GRAY);
		for (int i = 0; i < topPallette.size(); i++) {
			g2.fill(topPallette.get(i));
		}
		for (int i = 0; i < bottomPallette.size(); i++) {
			g2.fill(bottomPallette.get(i));
		}

		// Fill expected hole
		if (expectedHole != 27) {
			g2.setPaint(expectedColor);
			g2.fill(topPallette.get(expectedHole));
			g2.fill(bottomPallette.get(expectedHole));
		}

		// Fill actual hole
		if (actualHole != 27) {
			g2.setPaint(actualColor);
			g2.fill(topPallette.get(actualHole));
			g2.fill(bottomPallette.get(actualHole));
		}
		
//		// Draw the route visualize line.
//		if (visualizeLine == true) {
//			g2.setPaint(visualizeColor);
//		}
		
//		// Draw the movement line.
//		if (drawLine == true) {
//			g2.setPaint(lineColor);
//		}
//		
//		// Draw the cross (actual coordinates).
//		if (drawLine == true) {
//			g2.setPaint(crossColor);
//		}

		// Draw hole numbers.
		g2.setPaint(Color.BLACK);
		for (int i = 0; i < 10; i++) {
			g2.drawString(Integer.toString(i), (float) (topPallette.get(i).getCenterX()-3), (float) (topPallette.get(i).getCenterY()+4.375));
		}
		for (int i = 10; i < topPallette.size(); i++) {
			g2.drawString(Integer.toString(i), (float) (topPallette.get(i).getCenterX()-5), (float) (topPallette.get(i).getCenterY()+4.375));
		}
		for (int i = 0; i < 10; i++) {
			g2.drawString(Integer.toString(i), (float) (bottomPallette.get(i).getCenterX()-3), (float) (bottomPallette.get(i).getCenterY()+4.375));
		}
		for (int i = 10; i < bottomPallette.size(); i++) {
			g2.drawString(Integer.toString(i), (float) (bottomPallette.get(i).getCenterX()-5), (float) (bottomPallette.get(i).getCenterY()+4.375));
		}

	}

	public int getActualHole() {
		return actualHole;
	}

	public void setActualHole(int actualHole) {
		this.actualHole = actualHole;
	}

	public Color getActualColor() {
		return actualColor;
	}

	public void setActualColor(Color actualColor) {
		this.actualColor = actualColor;
	}

	public int getExpectedHole() {
		return expectedHole;
	}

	public void setExpectedHole(int expectedHole) {
		this.expectedHole = expectedHole;
	}

	public Color getExpectedColor() {
		return expectedColor;
	}

	public void setExpectedColor(Color expectedColor) {
		this.expectedColor = expectedColor;
	}
	
}
