package biorobot.test;


public class Test {
	public static void main(String[] args) {
		int zdir = 2;
		String zdir2 = String.format("%05d", zdir);
		System.out.println(zdir2);
	}
}
